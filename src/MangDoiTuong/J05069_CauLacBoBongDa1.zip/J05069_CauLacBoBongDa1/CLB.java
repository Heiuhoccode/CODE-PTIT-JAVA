/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MangDoiTuong.J05069_CauLacBoBongDa1;

/**
 *
 * @author admin
 */
public class CLB {
    private String id, name;
    private int giave;
    //
    public CLB(String id, String name, int giave){
        this.id = id;
        this.name = name;
        this.giave = giave;
    }
    //

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getGiave() {
        return giave;
    }
    
}
