/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UngDungJavaCollection.J08012_HinhSao;

import java.util.*;
public class Edge {
    private int vertex1, vertex2;
    //
    public Edge(int vertex1, int vertex2){
        this.vertex1 = vertex1;
        this.vertex2 = vertex2;
    }
    //
    public int getVertex1(){
        return vertex1;
    }
    public int getVertex2(){
        return vertex2;
    }
}
