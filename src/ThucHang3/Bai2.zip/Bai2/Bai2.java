/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ThucHang3.Bai2;

import java.util.*;
public class Bai2 {

    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        ArrayList<CongNhan> dscn = new ArrayList<>();
        while(n-- > 0){
            dscn.add(new CongNhan(sc.nextLine(),sc.nextLine(),sc.nextLine(),sc.nextLine()));
        }
        Collections.sort(dscn);
        for(CongNhan cn : dscn){
            System.out.println(cn);
        }
        
    }
    
}
