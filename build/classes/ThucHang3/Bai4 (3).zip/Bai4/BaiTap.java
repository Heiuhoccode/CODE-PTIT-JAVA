/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThucHang3.Bai4;

/**
 *
 * @author admin
 */
public class BaiTap {
    private String id, name, topic;
    //
    public BaiTap(String id, String name, String topic){
        this.id = id;
        this.name = name;
        this.topic = topic;
    }
    //

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getTopic() {
        return topic;
    }
    
}
