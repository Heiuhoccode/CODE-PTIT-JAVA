/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KhaiBaoLopVaDoiTuong.J04014_TinhToanPhanSo;

import java.util.*;
public class PhanSo {
    private int tu, mau;
    //
    public PhanSo(int tu, int mau){
        this.tu = tu;
        this.mau = mau;
    }
    //
    public int ucln(int a, int b){
        if(b==0) return a;
        return ucln(b, a%b);
    }
    //
    public int getTu(){
        return tu;
    }
    //
    public int getMau(){
        return mau;
    }
    //
    public void rutGon(){
        int uc = ucln(this.tu,this.mau);
        this.tu = this.tu/uc;
        this.mau = this.mau/uc;
    }
    //
    public String toString(){
        return tu+"/"+mau;
    }
}
